//
//  AppDelegate.h
//  JortecFilmFerret
//
//  Created by Rodrigo on 10/02/14.
//  Copyright (c) 2014 APPY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
