//
//  MovieDetailGridCell.h
//  JortecFilmFerret
//
//  Created by Rodrigo on 29/01/14.
//  Copyright (c) 2014 JFF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MovieDetailGridCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *posterImage;

@end
