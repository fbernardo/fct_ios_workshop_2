//
//  UIImageView+RemoteLoad.h
//  JortecFilmFerret
//
//  Created by Rodrigo on 28/01/14.
//  Copyright (c) 2014 JFF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (RemoteLoad)

- (void)setRemoteImageFromURL:(NSString*) url;

@end
